
import React, { useState, useCallback } from 'react';
import { Recipe, DietaryRestrictions, DietaryOption } from './types';
import { generateRecipes } from './services/geminiService';
import RecipeCard from './components/RecipeCard';
import LoadingSpinner from './components/LoadingSpinner';

// Simple SVG icons for dietary options
const GlutenFreeIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-5.25 0h-8.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="m15.75 12-3.375-3.375M15.75 12l-3.375 3.375" />
  </svg>
);

const LactoseFreeIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="m7.5 7.5.862 2.585M7.5 7.5V4.5m0 3L4.5 6m0 0v7.5A2.25 2.25 0 0 0 6.75 16h.75M17.25 7.5l.862 2.585M17.25 7.5V4.5m0 3L14.25 6m0 0v7.5a2.25 2.25 0 0 0 2.25 2.25h.75M12 21a9 9 0 0 0 9-9H3a9 9 0 0 0 9 9Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="m4.5 4.5 15 15" />
  </svg>
);

const SugarFreeIcon: React.FC<{ className?: string }> = ({ className }) => (
 <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" >
  <path strokeLinecap="round" strokeLinejoin="round" d="M14.25 6.083c-.097-.347-.282-.663-.538-.921a4.5 4.5 0 1 0-5.424 6.766 4.5 4.5 0 1 0 5.424-6.766Z" />
  <path strokeLinecap="round" strokeLinejoin="round" d="M12 3.475v1.921m0 13.109v1.92m6.071-6.071h-1.92m-13.109 0H5.02m11.233-4.159.96-1.663m-10.232 0L5.98 7.737m10.232 8.318-.96-1.664M5.98 16.263l-1.001-1.732" />
  <path strokeLinecap="round" strokeLinejoin="round" d="m4.5 4.5 15 15" />
</svg>
);

const dietaryOptionsConfig: DietaryOption[] = [
  { key: 'glutenFree', label: 'Sem Glúten', icon: <GlutenFreeIcon className="w-5 h-5 mr-2" /> },
  { key: 'lactoseFree', label: 'Sem Lactose', icon: <LactoseFreeIcon className="w-5 h-5 mr-2" /> },
  { key: 'sugarFree', label: 'Sem Açúcar', icon: <SugarFreeIcon className="w-5 h-5 mr-2" /> },
];

const App: React.FC = () => {
  const [recipeName, setRecipeName] = useState<string>('');
  const [dietaryRestrictions, setDietaryRestrictions] = useState<DietaryRestrictions>({
    glutenFree: false,
    lactoseFree: false,
    sugarFree: false,
  });
  const [generatedRecipes, setGeneratedRecipes] = useState<Recipe[] | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRecipeName(event.target.value);
  };

  const handleDietaryToggle = (optionKey: keyof DietaryRestrictions) => {
    setDietaryRestrictions(prev => ({
      ...prev,
      [optionKey]: !prev[optionKey],
    }));
  };

  const handleSubmit = useCallback(async (event: React.FormEvent) => {
    event.preventDefault();
    if (!recipeName.trim()) {
      setError('Por favor, insira o nome de uma receita.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setGeneratedRecipes(null);

    try {
      const recipes = await generateRecipes(recipeName, dietaryRestrictions);
      setGeneratedRecipes(recipes);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'Falha ao gerar receitas. Verifique sua chave de API e tente novamente.');
    } finally {
      setIsLoading(false);
    }
  }, [recipeName, dietaryRestrictions]);


  return (
    <div className="min-h-screen bg-light-bg text-text-main p-4 md:p-8">
      <header className="text-center mb-10">
        <h1 className="text-4xl md:text-5xl font-bold text-primary">Gerador de Receitas IA</h1>
        <p className="text-text-secondary mt-2 text-lg">Descubra novas versões dos seus pratos favoritos!</p>
      </header>

      <main className="max-w-3xl mx-auto">
        <form onSubmit={handleSubmit} className="bg-card-bg p-6 md:p-8 rounded-lg shadow-xl mb-12">
          <div className="mb-6">
            <label htmlFor="recipeName" className="block text-lg font-semibold text-text-main mb-2">
              Qual receita você gostaria de criar?
            </label>
            <input
              type="text"
              id="recipeName"
              value={recipeName}
              onChange={handleInputChange}
              placeholder="Ex: Bolo de Chocolate, Lasanha, Risoto de Cogumelos"
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary transition-shadow"
              required
            />
          </div>

          <div className="mb-8">
            <h3 className="text-lg font-semibold text-text-main mb-3">Restrições Alimentares:</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {dietaryOptionsConfig.map(option => (
                <button
                  key={option.key}
                  type="button"
                  onClick={() => handleDietaryToggle(option.key)}
                  className={`flex items-center justify-center px-4 py-3 rounded-lg border-2 transition-all duration-200 ease-in-out transform hover:scale-105
                    ${dietaryRestrictions[option.key]
                      ? 'bg-primary border-primary text-white shadow-md'
                      : 'bg-slate-100 border-slate-300 text-text-secondary hover:bg-slate-200'
                    }`}
                >
                  {option.icon}
                  <span className="font-medium">{option.label}</span>
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-primary hover:bg-primary-hover text-white font-bold py-3 px-6 rounded-lg text-lg transition-colors duration-200 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center shadow-md hover:shadow-lg"
          >
            {isLoading ? <LoadingSpinner /> : 'Gerar Receitas'}
          </button>
        </form>

        {error && (
          <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-8 rounded-md shadow" role="alert">
            <p className="font-bold">Erro</p>
            <p>{error}</p>
          </div>
        )}

        {generatedRecipes && generatedRecipes.length > 0 && (
          <div className="space-y-8">
            {generatedRecipes.map((recipe, index) => (
              <RecipeCard key={index} recipe={recipe} isClassic={index === 0} />
            ))}
          </div>
        )}
         {isLoading && !generatedRecipes && (
            <div className="flex justify-center items-center h-40">
                 <LoadingSpinner isLarge={true} />
            </div>
        )}
      </main>

      <footer className="text-center mt-12 py-6 border-t border-slate-300">
        <p className="text-text-secondary">Desenvolvido com IA e React</p>
      </footer>
    </div>
  );
};

export default App;
    