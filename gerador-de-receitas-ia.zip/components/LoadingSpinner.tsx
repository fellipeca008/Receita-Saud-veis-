
import React from 'react';

interface LoadingSpinnerProps {
  isLarge?: boolean;
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ isLarge = false }) => {
  const sizeClasses = isLarge ? 'h-10 w-10' : 'h-5 w-5';
  const borderClasses = isLarge ? 'border-4' : 'border-2';
  
  return (
    <div className="flex justify-center items-center">
      <div 
        className={`animate-spin rounded-full ${sizeClasses} ${borderClasses} border-t-transparent border-solid border-white ${isLarge ? 'border-primary' : ''}`}
        role="status"
        aria-label="Carregando..."
      >
        <span className="sr-only">Carregando...</span>
      </div>
       {isLarge && <p className="ml-3 text-primary text-lg">Gerando receitas incríveis...</p>}
    </div>
  );
};

export default LoadingSpinner;
    