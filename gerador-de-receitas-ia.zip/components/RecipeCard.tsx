
import React from 'react';
import { Recipe } from '../types';

interface RecipeCardProps {
  recipe: Recipe;
  isClassic?: boolean;
}

const RecipeCard: React.FC<RecipeCardProps> = ({ recipe, isClassic }) => {
  return (
    <div className={`bg-card-bg rounded-xl shadow-2xl overflow-hidden transition-all duration-300 hover:shadow-3xl ${isClassic ? 'border-2 border-primary' : 'border border-slate-200'}`}>
      <div className={`p-6 md:p-8 ${isClassic ? 'bg-primary/10' : ''}`}>
        <h2 className="text-2xl md:text-3xl font-bold text-primary mb-2">
          {recipe.title}
          {isClassic && <span className="text-sm font-semibold text-primary-hover ml-2">(Clássica)</span>}
        </h2>
        <p className="text-text-secondary mb-6 text-sm md:text-base">{recipe.description}</p>
      </div>
      
      <div className="px-6 md:px-8 pb-6 md:pb-8">
        <div className="mb-6">
          <h3 className="text-xl font-semibold text-text-main mb-3 border-b-2 border-primary/30 pb-2">Ingredientes:</h3>
          <ul className="list-disc list-inside space-y-1 text-text-secondary pl-2">
            {recipe.ingredients.map((ingredient, index) => (
              <li key={index} className="leading-relaxed">{ingredient}</li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-xl font-semibold text-text-main mb-3 border-b-2 border-primary/30 pb-2">Instruções:</h3>
          <ol className="list-decimal list-inside space-y-2 text-text-secondary pl-2">
            {recipe.instructions.map((instruction, index) => (
              <li key={index} className="leading-relaxed">{instruction}</li>
            ))}
          </ol>
        </div>
      </div>
    </div>
  );
};

export default RecipeCard;
    