
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Recipe, DietaryRestrictions } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // This will be caught by the App component and shown to the user.
  // In a real production app, you might have a more robust configuration check.
  throw new Error("API_KEY environment variable not set. Please configure your API key.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const constructPrompt = (recipeName: string, restrictions: DietaryRestrictions): string => {
  let restrictionsText = "";
  if (restrictions.glutenFree) restrictionsText += "- Adaptada para ser SEM GLÚTEN (ex: usar farinhas sem glúten, evitar ingredientes com glúten).\n";
  if (restrictions.lactoseFree) restrictionsText += "- Adaptada para ser SEM LACTOSE (ex: usar leite vegetal, queijos sem lactose, etc.).\n";
  if (restrictions.sugarFree) restrictionsText += "- Adaptada para ser SEM AÇÚCAR REFINADO (ex: usar adoçantes naturais como stevia, eritritol, frutas, ou reduzir significativamente o açúcar, focando em sabores naturais).\n";

  if (restrictionsText === "") {
    restrictionsText = "Nenhuma restrição alimentar específica. Siga as receitas tradicionais ou variações padrão.";
  }

  return `
Por favor, gere 3 receitas distintas para "${recipeName}".
A primeira receita DEVE ser a versão MAIS CLÁSSICA e tradicional possível do prato.
As outras duas receitas devem ser VARIAÇÕES CRIATIVAS E INTERESSANTES da receita original.

Restrições alimentares a aplicar (se alguma for listada abaixo, aplique a TODAS as 3 receitas de forma consistente):
${restrictionsText}

Para cada uma das 3 receitas, forneça os seguintes detalhes em formato JSON. O resultado DEVE ser um array JSON contendo exatamente 3 objetos de receita.

Cada objeto de receita deve ter os seguintes campos:
- "title": string (Ex: "Bolo de Cenoura com Cobertura de Chocolate (Clássico)", "Bolo de Cenoura Funcional com Biomassa de Banana Verde (Variação Sem Glúten)")
- "description": string (Uma breve descrição da receita, 2-4 frases, destacando o que a torna especial ou como as restrições foram aplicadas)
- "ingredients": array of strings (Lista detalhada de ingredientes com quantidades e unidades. Ex: ["2 xícaras de farinha de trigo", "3 ovos grandes", "1 colher de chá de extrato de baunilha"])
- "instructions": array of strings (Passos numerados e claros para o preparo. Ex: ["1. Preaqueça o forno a 180°C e unte uma forma.", "2. Em uma tigela grande, misture os ingredientes secos."])

Certifique-se de que a primeira receita no array JSON seja a versão clássica.
As variações devem ser distintas entre si e da clássica, oferecendo novas abordagens, ingredientes ou sabores.
Se houver restrições, detalhe como os ingredientes foram adaptados para cumpri-las, tanto nos ingredientes quanto na descrição.

Responda APENAS com o array JSON, nada antes ou depois.

Formato de resposta JSON estritamente como um array de 3 objetos:
[
  {
    "title": "Nome da Receita (Clássica)",
    "description": "Descrição da receita clássica, adaptada se houver restrições...",
    "ingredients": ["Ingrediente 1 (com quantidade)", "Ingrediente 2 (com quantidade)"],
    "instructions": ["Passo 1 detalhado...", "Passo 2 detalhado..."]
  },
  {
    "title": "Nome da Receita (Variação Criativa 1)",
    "description": "Descrição da variação 1, adaptada se houver restrições...",
    "ingredients": ["Ingrediente A (com quantidade)", "Ingrediente B (com quantidade)"],
    "instructions": ["Instrução A detalhada...", "Instrução B detalhada..."]
  },
  {
    "title": "Nome da Receita (Variação Criativa 2)",
    "description": "Descrição da variação 2, adaptada se houver restrições...",
    "ingredients": ["Ingrediente X (com quantidade)", "Ingrediente Y (com quantidade)"],
    "instructions": ["Instrução X detalhada...", "Instrução Y detalhada..."]
  }
]
`;
};

export const generateRecipes = async (recipeName: string, restrictions: DietaryRestrictions): Promise<Recipe[]> => {
  const prompt = constructPrompt(recipeName, restrictions);
  
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17", // Recommended model
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.7, // Add some creativity
      },
    });

    let jsonStr = response.text.trim();
    
    // Remove potential markdown fences (```json ... ```)
    const fenceRegex = /^```(?:json)?\s*\n?(.*?)\n?\s*```$/si;
    const match = jsonStr.match(fenceRegex);
    if (match && match[1]) {
      jsonStr = match[1].trim();
    }

    try {
      const parsedData = JSON.parse(jsonStr);
      if (Array.isArray(parsedData) && parsedData.length > 0 && 
          parsedData.every(item => item.title && item.description && item.ingredients && item.instructions)) {
        return parsedData as Recipe[];
      } else {
        console.error("Parsed JSON does not match expected Recipe[] structure:", parsedData);
        throw new Error("A resposta da IA não está no formato esperado de receitas.");
      }
    } catch (e) {
      console.error("Failed to parse JSON response from AI:", e);
      console.error("Raw response text:", response.text);
      throw new Error("Falha ao processar a resposta da IA. Verifique o formato do JSON retornado.");
    }

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error && error.message.includes("API key not valid")) {
       throw new Error("Chave de API inválida. Verifique sua configuração.");
    }
    throw new Error(`Erro ao comunicar com o serviço de IA: ${error instanceof Error ? error.message : String(error)}`);
  }
};
    