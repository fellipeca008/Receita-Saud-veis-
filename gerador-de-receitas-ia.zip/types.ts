
export interface Recipe {
  title: string;
  description: string;
  ingredients: string[];
  instructions: string[];
}

export interface DietaryRestrictions {
  glutenFree: boolean;
  lactoseFree: boolean;
  sugarFree: boolean;
}

// Used to map keys of DietaryRestrictions to user-friendly labels
export interface DietaryOption {
  key: keyof DietaryRestrictions;
  label: string;
  icon?: React.ReactNode; 
}
    